const cities = require('./zipCodeModule_v2');
const colors = require('colors');




cities.lookupByZipCode("02215");
cities.lookupByZipCode("99999");
console.log('\n')
cities.lookupByCityState("BOSTON","MA");
cities.lookupByCityState("BOSTON","TX");
cities.lookupByCityState("BOSTON","AK");
console.log('\n')
cities.getPopulationByState("MA");
cities.getPopulationByState("TX");
cities.getPopulationByState("AA");



