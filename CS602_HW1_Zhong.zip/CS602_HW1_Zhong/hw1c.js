const colors = require('colors');

const ZipCodeEmitter = require('./zipCodeEmitter').ZipCodeEmitter;

const cities = new ZipCodeEmitter();



// first one
cities.on("lookupByZipCode", (result) => {
    console.log("Event LookUpByZipCode raised!".blue);
    console.log(result);
});

// city state handler 1
cities.on("lookupByCityState", (result) => {
    console.log("Event LookupByCityState raised! (Handler1)".blue);
    console.log(result);
})

// city state handler 2
cities.on("lookupByCityState", (result) => {
    console.log("Event LookupByCityState raised! (Handler2)".blue);
    console.log(`city: ${result.city}, state: ${result.state}`.blue);
    for (n of result.data) {
        console.log(`${n.zip} has population of ${n.pop}`.blue); // id here is actually zip
    }
})

// population handler
cities.on("getPopulationByState", (result) => {
    console.log("Event getPopulationByState raised!".blue);
    console.log(result);
})


// testing
cities.lookupByZipCode("02215");
cities.lookupByCityState("BOSTON", "MA");
cities.getPopulationByState("MA");

