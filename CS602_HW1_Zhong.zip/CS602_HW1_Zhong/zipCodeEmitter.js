const EventEmitter = require('events').EventEmitter;
const data = require('./zips.json');


// Custom class 
class ZipCodeEmitter  extends EventEmitter {
	
	// member functions

	lookupByZipCode(zip)  {


        const str = "Look up by zip code("+ zip +")";
        console.log(str.red);

        var result = data.find((data) => data._id === zip); // find( (para)   => func body)

	    this.emit("lookupByZipCode", result);
	}

	lookupByCityState(city, state)  {
        const str = "Look up by city("+city+","+state+")";
        console.log(str.red);
        // find right data first


        // find all objs that match this condition
        const filtered_list_data = data.filter((x) => x.state === state && x.city === city);

        // for each obj in the above list, create a new list that consisting of zip and pop.
        const zip_pop_list = filtered_list_data.map((obj) => {return {zip: obj._id, pop: obj.pop}});

        // solution obj created
        let result_obj = {
            city: city,
            state: state,
            data: zip_pop_list
        }
        console.log(result_obj);

        this.emit("lookupByCityState", result_obj);
	}

	getPopulationByState(state) {
	 // find the right state
	    let filtered_list = data.filter((x) => x.state === state);

        const str = "Get Population By state("+state+")";
        console.log(str.red);

         // count the tot of pop, by adding each of them, with reduce
        const sum_pop = filtered_list.reduce(function (prev, curr){
        return prev + curr.pop}, 0)

         // correct structure
        let pop_obj = {
         state: state,
         pop: sum_pop
        }

         //return
        console.log(pop_obj)
        this.emit("getPopulationByState", pop_obj)
	}

}

module.exports.ZipCodeEmitter = ZipCodeEmitter;

