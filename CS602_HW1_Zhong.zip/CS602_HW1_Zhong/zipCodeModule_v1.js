const data = require('./zips.json'); // json file

module.exports.lookupByZipCode =  (zip) => {

    const str = "Look up by zip code("+ zip +")";
    console.log(str.red);

    for(const n of data){
        if(n._id === zip){ // find one with right zip
            console.log(n)
            return n;
        }

    };
    console.log("undefined") // return undefine when unfound
    return undefined;

    };


module.exports.lookupByCityState = (city, state) => {
    const str = "Look up by city("+city+","+state+")";
    console.log(str.red);

    // find right data first
    let result_data = [];

    for (const n of data){
        if(n.state === state && n.city === city){
            let zip_pop = {zip: n._id, pop: n.pop}; // this is the data we need to add into the list

            result_data.push(zip_pop);
        }
    }
	let result_obj = {
	    city: city,
	    state: state,
	    data: result_data
	}
	console.log(result_obj);

	return result_obj;

};

module.exports.getPopulationByState = (state) => {
    const str = "Get Population By state("+state+")";
    console.log(str.red);

    let tot = 0;

    for(const n of data){
        if(n.state === state){ // find right state
            tot += n.pop // add up all pop
        }

    }

    let pop_obj = {
        state: state,
        pop: tot
    }

    console.log(pop_obj)
    return pop_obj;

    };
