const net = require('net');

const colors = require('colors');

const cities = require('./zipCodeModule_v2');


// create Server
const server = net.createServer((socket) => {

	console.log("Client connection...".red);

	socket.on('end', () => {
		console.log("Client disconnected...".red);
	});

	// HW Code - Write the following code to process data from client
	// process data from client!

	socket.on('data', (data) => {

		let input = data.toString();
		console.log(colors.blue('...Received %s'), input);

		// to process data, execute it
		var command_arr = input.split(",");
		const command = command_arr;

		console.log("command is:", command);
		console.log(command[0]);
		console.log(command[1]);

		if(command[0] === 'lookupByZipCode'){
		console.log("looking up for zip code....")

		// return this to client
		var msg = JSON.stringify(cities.lookupByZipCode(command_arr[1]));
		socket.write(msg);
		}

		if(command[0] === 'lookupByCityState'){
		console.log("looking up for city state....")
		var msg = JSON.stringify(cities.lookupByCityState(command[1], command[2]));
		socket.write(msg);
		}

		if(command[0] === 'getPopulationByState'){
		console.log("Getting population by state....")
		var msg = JSON.stringify(cities.getPopulationByState(command[1]))
		socket.write(msg);
		}

        if(command[0] === 'lookupByState'){
        socket.write("Invalid request");
        }


    });


	});


// listen for client connections
server.listen(3000, () => {
	console.log("Listening for connections on port 3000");
});
