
const express = require('express');
const app = express();
const http = require("http");
// Use the zipCode module - functions
const cities = require('./zipCodeModule_v2');


// body-parser
const bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


// setup handlebars view engine
const handlebars = require('express-handlebars');
app.engine('handlebars',
	handlebars({defaultLayout: 'main'}));
// add a path to access view file
var path = require ('path');
const viewsPath = path.join(__dirname, './views')
app.set('view engine', 'handlebars');
app.set('views', viewsPath)

// static resources
app.use(express.static(__dirname + '/public'));




// GET request to the homepage
app.get('/',  (req, res) => {
res.render('homeView');
});


app.get('/zip', (req, res) => {
	res.render('lookupByZipForm');
});

app.post('/zip', (req, res) => {
   var bodyData = JSON.stringify(req.body);
   var id = req.body.id;

   const id_obj = {"zip": id};
   console.log(id_obj);

   //res.redirect(('/zip/') + id);

   res.render("lookupByZipView", {zip_info: id_obj, city: cities.lookupByZipCode(id)});

});

// Implement the JSON, XML, & HTML formats

app.get('/zip/:id', (req, res) => {
    res.format({
        'application/json': () => {
          res.json(cities.lookupByZipCode(req.params.id));
        },

        'application/xml': () => {
          let city = cities.lookupByZipCode(req.params.id)
          let citiesXml =
            '<?xml version="1.0">\n'
            + '<zipCode id=' + req.params.id + '>\n'
                                     + '<city>' + city.city + '</city>\n'
                                     + '<state>' + city.state + '</state>\n'
                                     + '<pop>' + city.pop + '</pop>\n'
                                     + '</zipCode>';
          res.type('application/xml');
          res.send(citiesXml);
        },

        'text/html': () => {
         var id = req.params.id;
         const id_obj = {"zip": id};
         res.render("lookupByZipView", {zip_info: id_obj, city: cities.lookupByZipCode(id)});

        }
      });
});


app.get('/city', (req, res) => {
	
	res.render("lookupByCityStateForm");
});

app.post('/city', (req, res) => {
    var bodyData = JSON.stringify(req.body);
    var city = req.body.city;
    var state = req.body.state;

    const request = {"city":city, "state": state};


   res.render("lookupByCityStateView", {city: JSON.parse(JSON.stringify(cities.lookupByCityState(city,state).data)), data: request});
   //res.send((cities.lookupByCityState(city,state)).data);
});









// Implement the JSON, XML, & HTML formats

app.get('/city/:city/state/:state', (req, res) => {
	 res.format({
            'application/json': () => {
              res.json(cities.lookupByCityState(req.params.city, req.params.state));
            },

            'application/xml': () => {
                      let citiesXml =
                        '<?xml version="1.0">\n'
                        + '<city-state city=' + req.params.city + ' state=' + req.params.state + '>\n';

                      let city = JSON.parse(JSON.stringify(cities.lookupByCityState(req.params.city, req.params.state).data))
                      for (var e of city){
                        citiesXml = citiesXml + '<entry zip=>' + e.zip + ' pop=' + e.pop + '/>\n';
                      }
                      citiesXml = citiesXml + '</city-state>\n';

                      res.type('application/xml');
                      res.send(citiesXml);
                    },



            'text/html': () => {
             var city = req.params.city;
             var state = req.params.state;

             const request = {"city":city, "state": state};

             res.render("lookupByCityStateView", {city: JSON.parse(JSON.stringify(cities.lookupByCityState(city,state).data)), data: request});
             //res.send((cities.lookupByCityState(city,state)).data);
            }
          });


});



app.get('/pop', (req, res) => {
	res.render("populationForm");
	
});

// Implement the JSON, XML, & HTML formats

app.get('/pop/:state', (req, res) => {
    res.format({
            'application/json': () => {
              res.json(cities.getPopulationByState(req.params.state));
            },

            'application/xml': () => {
                      let city = cities.getPopulationByState(req.params.state)
                      let citiesXml =
                        '<?xml version="1.0">\n'
                        + '<state-pop state=' + city.state + '>\n'
                                                 + '<pop>' + city.pop + '</pop>\n'
                                                 + '</state-pop>';
                      res.type('application/xml');
                      res.send(citiesXml);
            },

            'text/html': () => {
             var state = req.params.state;

             res.render("populationView", {city: cities.getPopulationByState(state)});

            }
          });

});


/// 404 page
app.use((req, res) => {
	res.status(404);
	res.render('404');
});

// listening to 3000 port
app.listen(3000, () => {
  console.log('http://localhost:3000');
});




