// Copy your solution from Assignment1


let data = require('./zips.json');

module.exports.lookupByZipCode =  (zip) => {
		

    const str = "Look up by zip code("+ zip +")";
    console.log(str.red);

    var result = data.find((data) => data._id === zip); // find( (para)   => func body)
    console.log(result);
    return result;

    };


module.exports.lookupByCityState = (city, state) => {
    const str = "Look up by city("+city+","+state+")";
    console.log(str.red);
    // find right data first


    // find all objs that match this condition
    const filtered_list_data = data.filter((x) => x.state === state && x.city === city);

    // for each obj in the above list, create a new list that consisting of zip and pop.
    const zip_pop_list = filtered_list_data.map((obj) => {return {zip: obj._id, pop: obj.pop}});

    // solution obj created
	let result_obj = {
	    city: city,
	    state: state,
	    data: zip_pop_list
	}
	return result_obj;

};

module.exports.getPopulationByState = (state) => {

   // find the right state
   let filtered_list = data.filter((x) => x.state === state);

    const str = "Get Population By state("+state+")";
    console.log(str.red);

    // count the tot of pop, by adding each of them, with reduce
    const sum_pop = filtered_list.reduce(function (prev, curr){
        return prev + curr.pop}, 0)

    // correct structure
    let pop_obj = {
        state: state,
        pop: sum_pop
    }

    //return
    console.log(pop_obj)
    return pop_obj;

    };
