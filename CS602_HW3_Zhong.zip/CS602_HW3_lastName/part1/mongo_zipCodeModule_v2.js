const MongoClient = require('mongodb').MongoClient;
const credentials = require("./credentials.js");

const dbUrl = 'mongodb+srv://' + credentials.username +
	':' + credentials.password + '@' + credentials.host + '/' + credentials.database;

let client = null;
//
//const getConnection = async () => {
//	if (client == null)
//		client = await MongoClient.connect(dbUrl,  { useNewUrlParser: true ,  useUnifiedTopology: true });
//	return client;
//}



const getConnection = async () => {
	if (client == null)
		client = await MongoClient.connect(dbUrl,  { useNewUrlParser: true ,  useUnifiedTopology: true });
	return client;
}


module.exports = {

    host:     'cluster0.kwjingk.mongodb.net',
    username: 'cs602_user',
    password: 'cs602_secret',
    database: 'cs602db'
}


module.exports.lookupByZipCode =  async (zip) => {

	let client = await getConnection();
	let collection = client.db(credentials.database).collection('zipcodes');
	
	let result = await collection.find({'_id': zip}).toArray();
	
	if (result.length > 0)
		return result[0];
	else
		return undefined;
};

// Complete the code for the following

module.exports.lookupByCityState = async (city, state) => {

	const str = "Look up by city("+city+","+state+")";
    console.log(str.red);
    // find right data first


	let client = await getConnection();
	let collection = client.db(credentials.database).collection('zipcodes');
    let data = await collection.find({'city': city,'state': state}).toArray();

    // find all objs that match this condition
    const filtered_list_data = data.filter((x) => x.state === state && x.city === city);

    // for each obj in the above list, create a new list that consisting of zip and pop.
    const zip_pop_list = filtered_list_data.map((obj) => {return {zip: obj._id, pop: obj.pop}});

    // solution obj created
	let result_obj = {
	    city: city,
	    state: state,
	    data: zip_pop_list
	}
	return result_obj;

};


module.exports.getPopulationByState =

//
//	data = getModel();


	async (state) => {


    // find all data
	let client = await getConnection();
	let collection = client.db(credentials.database).collection('zipcodes');

	let data = await collection.find({'state': state}).toArray();

		 // find the right state
   let filtered_list = data.filter((x) => x.state === state);

    const str = "Get Population By state("+state+")";
    console.log(str.red);

    // count the tot of pop, by adding each of them, with reduce
    const sum_pop = filtered_list.reduce(function (prev, curr){
        return prev + curr.pop}, 0)

    // correct structure
    let pop_obj = {
        state: state,
        pop: sum_pop
    }

    //return
    console.log(pop_obj)
    return pop_obj;

    };


