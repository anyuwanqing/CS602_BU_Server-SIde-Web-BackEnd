module.exports = {
	host:     'cluster0.s5w3gyc.mongodb.net',
	username: 'admin',
	password: 'admin',
	database: 'myFirstDatabase'
}

