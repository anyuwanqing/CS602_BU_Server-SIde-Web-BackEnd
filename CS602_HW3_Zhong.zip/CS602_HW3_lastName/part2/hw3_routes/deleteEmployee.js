const employeeDB = require('../employeeDB.js');
const Employee = employeeDB.getModel();

module.exports = async (req , res , next) => {
    
    // Fill in the code

let id = req.params.id;

  Employee.findById(id, (err, employee) => {
    if(err) console.log("Cannot find employee: %s", err);
    if(!employee) return res.render('404');


    // render delete site, and wait for 'submit' command.
    // send default data which is f and lname
    res.render("deleteEmployeeView", {data: {id: employee._id,
                                                 firstName: employee.firstName,
                                                 lastName: employee.lastName}
                                               });


});

};

