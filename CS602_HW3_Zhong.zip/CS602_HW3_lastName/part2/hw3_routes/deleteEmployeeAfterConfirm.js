const employeeDB = require('../employeeDB.js');
const Employee = employeeDB.getModel();



var ObjectID = require('mongodb').ObjectID;


module.exports =  async (req , res , next) => {
    
    // Fill in the code
    
        //var delete_id = request.params.id;//your id

         //collection.deleteOne({_id: new mongodb.ObjectID(delete_id.toString())});

    let id = req.params.id;



    // find the right employee to delete.
      Employee.findById(id, (err, employee) => {

          employee.OK((err) => {
            // delete it.
                employee.remove( (err) => {
                  if(err) console.log("Error deleting employee: %s", err);
                  res.redirect('/employees');
                });
          });


  });




};




  