const employeeDB = require('../employeeDB.js');
const Employee = employeeDB.getModel();

module.exports = async (req , res , next) => {

    // Fill in the code

    let id = req.params.id;

  Employee.findById(id, (err, employee) => {
// if error, print the error message, and if there isn't an employee, go to 404
// if find, render editPage

    if(err) console.log("Cannot find employee:%s ",err);
    if(!employee) return res.render('404');


// add the default data to view
    res.render('editEmployeeView', {data: {id: employee._id,
              firstName: employee.firstName,
              lastName: employee.lastName}
            });
  });
};

