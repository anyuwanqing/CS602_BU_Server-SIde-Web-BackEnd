var express = require('express');
var router = express.Router();

// other modules
var displayEmployees 	= require("./displayEmployees"); // done
var addEmployee 			= require("./addEmployee");  //done
var saveEmployee 			= require("./saveEmployee"); // done
var editEmployee 			= require("./editEmployee"); //done
var saveAfterEdit 	= require("./saveAfterEdit");  // TODO
var deleteEmployee 		= require("./deleteEmployee"); //done
var deleteEmployeeAfterConfirm 		= require("./deleteEmployeeAfterConfirm");


// router specs
router.get('/', function(req, res, next) {
  res.redirect('/employees');
});

// display all employees
router.get('/employees', displayEmployees);

// add a new employee
router.get('/employees/add', addEmployee);

// save the added employee
router.post('/employees/add', saveEmployee);

// edit employee
router.get('/employees/edit/:id', editEmployee);

// save after editing employee
router.post('/employees/edit/:id', saveAfterEdit);


// delete an employee
router.get('/employees/delete/:id', deleteEmployee);

//confirm employee deleted.
router.post('/employees/delete/:id', deleteEmployeeAfterConfirm);

module.exports = router;
