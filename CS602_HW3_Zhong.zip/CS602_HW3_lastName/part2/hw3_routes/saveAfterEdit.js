const employeeDB = require('../employeeDB.js');
const Employee = employeeDB.getModel();

module.exports = async (req , res , next) => {

// for posting the changes after editing an employee

    // Fill in the code
     let id = req.params.id;

     let fname = req.body.fname;
     let lname = req.body.lname;



// find this specific employee, and update his name
  Employee.findById(id, (err, employee) => {
    if(err) console.log("Cannot find employee: %s ", err);
    if(!employee) res.sent("error");



// find the employee based on its id, and then change its f/l name
// according to user input
    employee.firstName = fname;
    employee.lastName = lname;


// when save, post to /employee
    employee.save((err) => {
      if(err) console.log("Error updating employee: %s ", err);
      res.redirect('/employees');
    });


    });




    
 };
