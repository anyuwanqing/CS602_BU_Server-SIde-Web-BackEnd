{\rtf1\ansi\ansicpg1252\cocoartf2580
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;\f1\fnil\fcharset0 HelveticaNeue-Bold;\f2\fnil\fcharset0 HelveticaNeue;
}
{\colortbl;\red255\green255\blue255;\red220\green161\blue13;}
{\*\expandedcolortbl;;\cssrgb\c89412\c68627\c3922;}
{\*\listtable{\list\listtemplateid1\listhybrid{\listlevel\levelnfc23\levelnfcn23\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{hyphen\}}{\leveltext\leveltemplateid1\'01\uc0\u8259 ;}{\levelnumbers;}\fi-360\li720\lin720 }{\listname ;}\listid1}}
{\*\listoverridetable{\listoverride\listid1\listoverridecount0\ls1}}
\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 README\
\
Practice on php to calculate and display tax, by categories.\
\pard\pardeftab560\pardirnatural\partightenfactor0

\f1\b\fs40 \cf0 \
\pard\pardeftab560\slleading20\pardirnatural\partightenfactor0

\f2\b0\fs26 \cf0 \
\pard\pardeftab560\slleading20\partightenfactor0
\cf0 Download php (Mac):\
curl -s https://php-osx.liip.ch/install.sh | bash -s 7.3\
\
\pard\pardeftab560\slleading20\pardirnatural\partightenfactor0
\cf0 \
\pard\pardeftab560\slleading20\partightenfactor0
\cf0 Run in terminal:\
\pard\pardeftab560\slleading20\pardirnatural\partightenfactor0
\cf0 php -S localhost:8080\
\
\pard\pardeftab560\slleading20\partightenfactor0
\cf0 Go to server localhost:8080 and access the file at:\
\pard\pardeftab560\pardirnatural\partightenfactor0
\ls1\ilvl0
\fs24 \cf0 {\listtext	\uc0\u8259 	}{\field{\*\fldinst{HYPERLINK "http://localhost:8080/income_tax_v1.php"}}{\fldrslt 
\fs26 \cf2 http://localhost:8080/income_tax_v1.php}}
\fs26 \
\ls1\ilvl0
\fs24 {\listtext	\uc0\u8259 	}
\fs26 http://localhost:8080/income_tax_v2.php\
\pard\pardeftab560\slleading20\pardirnatural\partightenfactor0
\cf0 \
}