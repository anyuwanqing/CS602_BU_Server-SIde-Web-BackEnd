<?php
    require_once('database.php');

// Get the course form data
$courseName = filter_input(INPUT_POST, 'course_name');
$courseID = filter_input(INPUT_POST, 'course_id');



// if not valid
if ($courseName == null || $courseID == null){
    $error = "invalid course info";
    include('error.php');

// if valid, add course
}else{
    require_once('database.php');

    $command = 'INSERT INTO sk_courses
                   (courseID, courseName)
                   VALUES
                   (:courseID, :courseName)';
   $statement = $db->prepare($command);
   $statement->bindValue(':courseName', $courseName);
   $statement->bindValue(':courseID', $courseID);
   $statement->execute();
   $statement->closeCursor();


    // Display the Course List page
    include('course_list.php');
}

?>





