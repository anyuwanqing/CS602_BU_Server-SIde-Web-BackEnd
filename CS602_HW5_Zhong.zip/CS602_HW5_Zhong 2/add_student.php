<?php
    
    require_once('database.php');

// Get the student form data
    $courseID = filter_input(INPUT_POST, 'course_id');
    $firstName = filter_input(INPUT_POST, 'first_name');
    $lastName = filter_input(INPUT_POST, 'last_name');
    $email = filter_input(INPUT_POST, 'email');


// if not valid
if ($courseID == null || $firstName == null || $lastName == null || $email == null) {
    $error = 'invalid student info. Enter again.';

    include('error.php');
    include('add_student_form.php');

// if valid
}else{

    // Add the student to the database

    require_once('database.php');

    $command = 'INSERT INTO sk_students (courseID, firstName, lastName, email)
                       VALUES (:courseID, :firstName, :lastName, :email)';
    $statement = $db->prepare($command);
    $statement->bindValue('courseID', $courseID);
    $statement->bindValue('firstName', $firstName);
    $statement->bindValue('lastName', $lastName);
    $statement->bindValue('email', $email);
    $statement->execute();
    $statement->closeCursor();

    // Display the Student List page
    include('index.php');

}
?>