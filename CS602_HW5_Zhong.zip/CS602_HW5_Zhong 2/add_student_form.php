<?php
require('database.php');

// get all courses
$courseStatement = $db->prepare("SELECT * FROM sk_courses ORDER BY courseID");
$courseStatement->execute();
$courses = $courseStatement->fetchAll();
$courseStatement->closeCursor();

?>
<!DOCTYPE html>
<html>



<!-- the head section -->
<head>
    <title>My Course Manager</title>
    <link rel="stylesheet" type="text/css" href="main.css">
</head>



<!-- the body section -->
<body>
    <header><h1>Course Manager</h1></header>

    <main>
        <h1>Add Student</h1>
        <form action="add_student.php" method="post"
              id="add_student_form">



            <!-- dropdown course select -->
            <label>Course:</label>
             <select id="course_id" name="course_id">
            <?php foreach ($courses as $course) : ?>

                <option value="<?php echo $course['courseID']; ?>">
                    <?php echo $course['courseID'] . '- ' . $course['courseName'];?>
                </option>

            <?php endforeach ?>
            </select>
            <br><br>

            
            <label for="first_name">First Name:</label>
            <input type="text" id="first_name" name="first_name"><br>

            <label for="last_name">Last Name:</label>
            <input type="text" id="last_name" name="last_name"><br>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email"><br>


            <label>&nbsp;</label>
            <input type="submit" value="Add Student"><br>
        </form>
        <p><a href="index.php">View Student List</a></p>
    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Zaiyang Z</p>
    </footer>
</body>
</html>