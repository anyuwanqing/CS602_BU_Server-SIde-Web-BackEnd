<?php
    $dsn = 'mysql:host=127.0.0.1;dbname=cs602db';

// use root to debug, then change to the new user.

//    $username = 'root';
//    $password = 'root';
    $username = 'cs602_user';
    $password = 'cs602_secret';

    try {
        $db = new PDO($dsn, $username, $password);
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        include('database_error.php');
        exit();
    }
?>

