<?php
require_once('database.php');

// Delete the student from the database



// get student data from form.
$studentID = filter_input(INPUT_POST, 'student_id');
$courseID = filter_input(INPUT_POST, 'course_id'); // this is used below in index.php to show the current course


// if not valid, else
if ($studentID == null || $courseID == null) {
    $error = 'invalid input for student data.  Enter again.';
    include('error.php');

} else {

    // delete
    include('database.php');
    $command = 'DELETE FROM sk_students WHERE studentID = :studentID';
    $statement = $db->prepare($command);
    $statement->bindValue('studentID', $studentID);
    $statement->execute();
    $statement->closeCursor();

}







// Display the Home page
include('index.php');


?>