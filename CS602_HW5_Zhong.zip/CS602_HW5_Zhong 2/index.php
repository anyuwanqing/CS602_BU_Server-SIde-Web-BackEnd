<?php
require_once('database.php');


// get course id
if (!isset($courseID)) {
    $courseID = filter_input(INPUT_GET, 'courseID');

    // no selection, make it default to the first course
    if ($courseID == null) {
        $courseID = $courses[0]['courseID'];
    }
}


// get course data from database
$courseCommand = "SELECT * FROM sk_courses ORDER BY courseID";

$courseStatement = $db->prepare($courseCommand);
$courseStatement->execute();

$courses = $courseStatement->fetchAll();
$courseStatement->closeCursor();




// get current course name
$selectCourseByID = 'SELECT courseName FROM sk_courses WHERE courseID = :courseID';
$nameStatement = $db->prepare($selectCourseByID);
$nameStatement->bindValue(':courseID', $courseID);
$nameStatement->execute();
$courseName = $nameStatement->fetch()['courseName'];
$nameStatement->closeCursor();


// get student info from selected course
$studentCommand = "SELECT * FROM sk_students WHERE courseID = :courseID";
$studentStatement = $db->prepare($studentCommand);
$studentStatement->bindValue(':courseID', $courseID);
$studentStatement->execute();
$students = $studentStatement->fetchAll();
$studentStatement->closeCursor();

?>

<!DOCTYPE html>
<html>

<!-- the head section -->
<head>
    <title>My Course Manager</title>
    <link rel="stylesheet" type="text/css" href="main.css" />
</head>



<!-- the body section -->
<body>
<header><h1>Course Manager</h1></header>
<main>
    <center><h1>Student List</h1></center>

    <aside>
        <!-- display a list of categories -->
        <h2>Courses</h2>
        <nav>
        <ul>
             <!-- for each course -->
                        <?php foreach($courses as $course) : ?>
                            <li><a href=".?courseID=<?php echo $course['courseID']; ?>">
                                <?php echo $course['courseID']; ?>
                            </a></li>
                        <?php endforeach ?>
        </ul>
        </nav>          
    </aside>

    <section>
        <!-- display a table of Students -->

        <h2><?php echo $courseID . ' - ' . $courseName ?></h2>

        <!-- student table-->
        <table>
            <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>&nbsp;</th>
            </tr>
            <!-- for each get data-->
            <?php foreach ($students as $student) : ?>
            <tr>
                <td><?php echo $student['firstName']; ?></td>
                <td><?php echo $student['lastName']; ?></td>
                <td><?php echo $student['email']; ?></td>


                <!-- delete student form, default hidden-->
                <td><form action="delete_student.php" method="post">
                        <input type="hidden" name="student_id" value="<?php echo $student['studentID']; ?>">
                        <input type="hidden" name="course_id" value="<?php echo $student['courseID']; ?>">
                        <input type="submit" value="Delete">
                </form></td>
            </tr>
            <?php endforeach ?>

        </table>

        <p><a href="add_student_form.php">Add Student</a></p>

        <p><a href="course_list.php">List Courses</a></p>

    </section>
</main>

<footer>
    <p>&copy; <?php echo date("Y"); ?> Zaiyang Zhong</p>
</footer>
</body>
</html>