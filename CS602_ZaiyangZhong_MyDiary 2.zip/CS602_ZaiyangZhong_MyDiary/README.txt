
README

HOW TO RUN - My Diary Managament
_____________
First go to online Mongodb and run it
Change credentials in credentials.js
Open terminal, run mongodb link (given in website)
Open the second terminal, run
- npm install
Run the command to initialize database
- node part2/initDB.js
Run the command to start server
- node part2/server.js


Go to
localhost:8080/user/list
to view all diaries


IMPLEMENTATION
_________
Working with Node and Mongodb,

Rest - curl test with
localhost:8080/month/:month


I struggled with authentication with login system and after ten hours of trying I gave up so I didn't implement it.
I spent most time on the search functions.
Instead it is a diary management site without any front end implementation.
