module.exports = {
  host: "cluster0.s5w3gyc.mongodb.net",
  username: "admin",
  password: "qwedsa",
  database: "myFirstDatabase",
};
