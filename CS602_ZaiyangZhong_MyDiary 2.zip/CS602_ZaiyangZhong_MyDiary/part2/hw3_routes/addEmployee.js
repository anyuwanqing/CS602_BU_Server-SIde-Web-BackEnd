module.exports = (req , res , next) => {
		
	res.render('addEmployeeView', {title: 'Add User'});

};
