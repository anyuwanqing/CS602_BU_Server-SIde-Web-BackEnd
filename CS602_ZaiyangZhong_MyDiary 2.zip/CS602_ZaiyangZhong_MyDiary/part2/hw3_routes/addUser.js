const userDB = require('../userDB.js');
const User = userDB.getModel();



// Add user view
module.exports = async (req, res) => {
	res.render('userAddView', {});

}
