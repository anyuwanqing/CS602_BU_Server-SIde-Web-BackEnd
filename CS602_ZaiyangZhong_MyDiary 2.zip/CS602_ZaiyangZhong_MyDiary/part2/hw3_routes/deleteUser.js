const userDB = require('../userDB.js');
const User = userDB.getModel();

module.exports = async (req , res) => {

    // Fill in the code

let id = req.params.id;

User.findById(id, (err, user) => {
if(err) console.log("Cannot find user: %s", err);

// render delete site, and wait for 'submit' command.
// send default data which is f and lname
res.render("deleteUserView", {data: {id: user._id,
                                             email: user.email,
                                             password: user.password}
                                           });


});

};

