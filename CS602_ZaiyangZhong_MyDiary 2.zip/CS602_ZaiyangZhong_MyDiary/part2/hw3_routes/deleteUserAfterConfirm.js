const userDB = require('../userDB.js');
const User = userDB.getModel();



var ObjectID = require('mongodb').ObjectID;


module.exports = async (req , res) => {


    // Fill in the code
    let id = req.body.id;

    let user = await User.findById(id);

    if (!user) {
      res.render('404');
      console.log("can't delete")
    } else {
      await user.remove();
      res.redirect('/user/list');
    }

  };






