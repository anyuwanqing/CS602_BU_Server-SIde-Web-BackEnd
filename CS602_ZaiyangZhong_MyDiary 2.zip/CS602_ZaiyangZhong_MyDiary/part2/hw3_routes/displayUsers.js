const userDB = require('../userDB.js');
const Users = userDB.getModel();


// List users view
module.exports = async (req , res)  => {

    let User = Users.find({});

    // Find all users then render html
    User.find({}, (err, users) => {
        if (err || !users) return res.render('error', {
            title: 'Error',
            msg: err || 'No users found.',
            user: req.session.user
        })
        var bool;
        if (users.admin){
        bool = 'true'}else{bool = 'false'};
        const results = users.map(user => {
            return {
                id: user._id,
                email: user.email,
                password: user.password,
                admin: user.admin,
                updatedAt: user.updatedAt
            }
        })
        return res.render('userListView', {
            title: "Diary List",
            data: results,
            user: users.email
        })
    })
}
