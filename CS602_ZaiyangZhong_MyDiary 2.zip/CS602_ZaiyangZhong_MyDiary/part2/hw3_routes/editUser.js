const userDB = require('../userDB.js');
const User = userDB.getModel();


module.exports = async (req , res , next) => {
    const id = req.params.id
    // Find user then send information to edit form
    User.findById(id, (err, user) => {
        if (err) return res.render('error', {
            title: 'Error',
            msg: err,
            user: user.email
        })
        return res.render('userEditView', {
            title: "Edit Diary",
            data: {
                id: user._id,
                email: user.email,
                password: user.password,
                admin: user.admin,
                number: user.number,
                salary: user.salary
            },
            user: user.email
        })
    })
}