const userDB = require("../userDB.js");
const User = userDB.getModel();

module.exports = async (req, res, next) => {
  const email = req.body.email.replace(/ /g, "");
  // Find user then send information to edit form
  // Find all users then render html
  User.find({ email: { $regex: "(.*)" + email + "(.*)" } }, (err, users) => {
    if (err || !users)
      return res.render("error", {
        title: "Error",
        msg: err || "No users found.",
        user: req.session.user,
      });
    var bool;
    if (users.admin) {
      bool = "true";
    } else {
      bool = "false";
    }
    const results = users.map((user) => {
      return {
        id: user._id,
        email: user.email,
        password: user.password,
        admin: user.admin,
        updatedAt: user.updatedAt,
      };
    });
    return res.render("userListView", {
      title: "Diary List",
      data: results,
      user: users.email,
      value: email,
    });
  });
};
