var express = require("express");
var router = express.Router();
let data = require("../diary.json")

// other modules
var displayUsers = require("./displayUsers");
var emailUsers = require("./emailUsers");
var addUser = require("./addUser");
var deleteUserAfterConfirm = require("./deleteUserAfterConfirm");
var deleteUser = require("./deleteUser");
var saveUser = require("./saveUser");
var editUser = require("./editUser");
var saveAfterEditUser = require("./saveAfterEditUser");
var search = require("./search");
var searchUser = require("./searchUser");



function simpleStringify (object){
    // stringify an object, avoiding circular structures
    // https://stackoverflow.com/a/31557814
    var simpleObject = {};
    for (var prop in object ){
        if (!object.hasOwnProperty(prop)){
            continue;
        }
        if (typeof(object[prop]) == 'object'){
            continue;
        }
        if (typeof(object[prop]) == 'function'){
            continue;
        }
        simpleObject[prop] = object[prop];
    }
    return JSON.stringify(simpleObject); // returns cleaned up JSON
};


function cleanStringify(object) {
    if (object && typeof object === 'object') {
        object = copyWithoutCircularReferences([object], object);
    }
    return JSON.stringify(object);

    function copyWithoutCircularReferences(references, object) {
        var cleanObject = {};
        Object.keys(object).forEach(function(key) {
            var value = object[key];
            if (value && typeof value === 'object') {
                if (references.indexOf(value) < 0) {
                    references.push(value);
                    cleanObject[key] = copyWithoutCircularReferences(references, value);
                    references.pop();
                } else {
                    cleanObject[key] = '###_Circular_###';
                }
            } else if (typeof value !== 'function') {
                cleanObject[key] = value;
            }
        });
        return cleanObject;
    }
}

//console.log(cleanStringify(User.findB()));

// router specs
router.get("/", function (req, res, next) {
  res.redirect("/user/list");
});




// implement JSON and xml
router.get('/month/:month', (req, res) => {
    res.format({
        'application/json': () => {
        const data = require("../diary.json")
        var month = req.params.month;
        var result = data.find((data) => data.month === month); // find( (para)   => func body)
          res.json(data);
        },

        'application/xml': () => {
          let data = require("../diary.json")
          var month = req.params.month;
          var result = data.find((data) => data.month === month);
          //data = JSON.parse(result);
          if (result){
          let diaryXml =
            '<?xml version="1.0">\n'
            + '<diary id=' + id + '>\n'
                                     + '<title>' + result.title + '</title>\n'
                                     + '<content>' + result.content + '</content>\n'
                                     + '<month>' + result.month + '</month>\n'
                                     + '<date>' + result.date + '</date>\n'
                                     + '</diary>';
          res.send(diaryXml);
          }else{
          res.send("error finding")}
        }



      });
});

router.get('/month/:month/date/:date', (req, res) => {
    res.format({
        'application/json': () => {
        const data = require("../diary.json")
        var month = req.params.month;
        var date = req.params.date;

        // find all objs that match this condition
        const filtered_list_data = data.filter((x) => x.month === month && x.date === date);
        console.log("1" + filtered_list_data);
        // for each obj in the above list, create a new list that consisting of zip and pop.
        const list = filtered_list_data.map((x) => {return {title: x.title, content: x.content, month: x.month, date: x.date}});
        console.log("2" + list);
        let diary = {
        month: month,
        date: date,
        diary: list
        }

        res.json(diary);
        },

        'application/xml': () => {
         const data = require("../diary.json")
                 var month = req.params.month;
                 var date = req.params.date;

                 // find all objs that match this condition
                 const filtered_list_data = data.filter((x) => x.month === month && x.date === date);
                 const result = filtered_list_data.map((x) => {return {title: x.title, content: x.content, month: x.month, date: x.date}});
                 if (result){
                           let diaryXml =
                             '<?xml version="1.0">\n'
                             + '<diary id=' + id + '>\n'
                                                      + '<title>' + result.title + '</title>\n'
                                                      + '<content>' + result.content + '</content>\n'
                                                      + '<month>' + result.month + '</month>\n'
                                                      + '<date>' + result.date + '</date>\n'
                                                      + '</diary>';
                           res.send(diaryXml);
                           }else{
                           res.send("error finding")}

        }

      });
});



router.get("/user",)
// display all users
router.get("/user/list", displayUsers);
router.post("/user/email", emailUsers);
// add new
router.get("/user/add", addUser);
// save user
router.post("/user/add", saveUser);

// edit employee
router.get("/user/edit/:id", editUser);

// save after editing employee
router.post("/user/edit/:id", saveAfterEditUser);

// delete an employee
router.get("/user/delete/:id", deleteUser);

//confirm employee deleted.
router.post("/user/delete/:id", deleteUserAfterConfirm);

router.get("/user/search", search);

router.post("/user/search", searchUser);


module.exports = router;
