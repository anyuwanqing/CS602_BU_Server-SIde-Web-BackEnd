const userDB = require('../userDB.js');
const User = userDB.getModel();


module.exports = async (req , res , next) => {

    const id = req.body.id
    // Find user, update values, save, then reload page
    User.findById(id, (err, user) => {
        if (err) return res.render('error', {
            title: 'Error',
            msg: err,
            user: user.email
        })
        user.email = req.body.email
        user.password = req.body.password
        user.admin = Boolean(req.body.admin)
        user.salary = req.body.salary
        user.number = req.body.employID

        user.save((err) => {
            if (err) return res.render('error', {
                title: 'Error',
                msg: err,
                user: user.email
            })
            return res.redirect('/user/list')
        })
    })
}