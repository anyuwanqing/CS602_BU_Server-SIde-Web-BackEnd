const userDB = require("../userDB.js");
const User = userDB.getModel();

module.exports = async (req, res, next) => {
  // for posting an added employee

  // Fill in the code

  console.log(req.body.admin, "req.body.admin");
  let employee = new User({
    email: req.body.email,
    password: req.body.password,
    admin: req.body.admin ? true : false,
  });

  employee.save((err) => {
    if (err) console.log("Error encountered: %s", err);
    res.redirect("/user/list");
  });
};
