module.exports = (req , res , next) => {

	res.render('userSearchView', {});

};
