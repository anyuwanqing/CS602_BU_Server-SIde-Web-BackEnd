const userDB = require("../userDB.js");
const Users = userDB.getModel();

// Add user view
module.exports = async (req, res) => {
  res.render("userAddView", {});

  let title = req.body.search;
  Users.find(
    {
      $or: [
        { username: { $regex: "(.*)" + title + "(.*)" } },
        { title: { $regex: "(.*)" + title + "(.*)" } },
      ],
    },
    (err, user) => {
      if (err) console.log("Error : %s ", err);

      // set error message if no product was found
      if (user.length < 1) {
        queryMsg = "Sorry, no results found.";
      }

      let results = users.map((u) => {
        return {
          id: u._id,
          name: u.email,
          password: u.password,
        };
      });
      res.render("user/displaySearch", {
        title: "List of Searched Users",
        data: results,
        queryMsg: queryMsg,
      });
    }
  );
};
