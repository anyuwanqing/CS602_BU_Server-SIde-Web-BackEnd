const diaryDB = require('./employeeDB.js');
const userDB = require('./userDB.js')

const Diary = diaryDB.getModel();
const User = userDB.getModel();


(async() => {

	await Diary.deleteMany({});
//
//	let d1 = new Diary({
//		title:'Today is a good day',time:'22-01-18', content:'I hang out with friends.'
//	});
//
//
//	let d2 = new Diary({
//		title:'received a love letter',time:'23-03-01', content:'No, I wont tell you its from whom.'
//	});

    let admin = new User({
                        email: 'Breeze-of-wind',
                        password: 'I love the breeze of wind',
                        admin: false,
                        number: 5,
                        salary: 2
                    })
    let user = new User({
        email: 'Love-Letter',
        password: 'Received a love letter today',
        admin: true,
        number: 4,
        salary: 3
    })



	await Promise.all([
//			d1.save(),
//			d2.save(),
			admin.save(),
			user.save()
		]);


	process.exit();


})();












