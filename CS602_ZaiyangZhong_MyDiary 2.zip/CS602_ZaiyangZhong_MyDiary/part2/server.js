var express = require('express');
var bodyParser = require('body-parser');
var handlebars = require('express-handlebars');


var session = require('express-session')
// Initialize Express Session


var app = express();

// setup handlebars view engine
app.engine('handlebars', 
    handlebars({defaultLayout: 'main_logo'}));
app.set('view engine', 'handlebars');


// EDIT path add a path to access view file
var path = require ('path');
const viewsPath = path.join(__dirname, './views')
app.set('views', viewsPath)


// static resources
app.use(express.static(__dirname + '/public'));

// body parser
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

// Routing
var routes = require('./hw3_routes/index.js');
app.use('/', routes);


app.use(function(req, res) {
    res.status(404);
    res.render('404');
});

app.listen(8080, function(){
  console.log('http://localhost:8080');
});

