const mongoose = require('mongoose');

const credentials = require("./credentials.js");

//  mongosh "mongodb+srv://cluster0.s5w3gyc.mongodb.net/myFirstDatabase" --apiVersion 1 --username admin


const dbUrl = 'mongodb+srv://' + credentials.username +
	':' + credentials.password + '@' + credentials.host + '/' + credentials.database;

let connection = null;
let model = null;

let Schema = mongoose.Schema;



const userSchema = new Schema({
    email: String,
    password: String,
    admin: Boolean,
    number: Number,
    salary: Number
}, {
    collection: 'users',
    timestamps: true,
})

module.exports = {
    getModel: () => {
        const connection = mongoose.createConnection(dbUrl, {
            useNewUrlParser: true,
            useUnifiedTopology: true
        })
        return connection.model("UserModel", userSchema)
    }
}